// screen2_bloc.dart
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:dio/dio.dart';

enum Screen2Event { fetchPosts }

class Screen2State {
  final List<dynamic> posts;
  final bool loading;

  Screen2State({required this.posts, required this.loading});
}

class Screen2Bloc extends Bloc<Screen2Event, Screen2State> {
  Screen2Bloc() : super(Screen2State(posts: [], loading: false));

  @override
  Stream<Screen2State> mapEventToState(Screen2Event event) async* {
    if (event == Screen2Event.fetchPosts) {
      yield* _mapFetchPostsToState();
    }
  }

  Stream<Screen2State> _mapFetchPostsToState() async* {
    yield Screen2State(posts: state.posts, loading: true);
    try {
      final response =
      await Dio().get('http://jsonplaceholder.typicode.com/posts');
      yield Screen2State(posts: response.data, loading: false);
    } catch (e) {
      print(e.toString());
      yield Screen2State(posts: state.posts, loading: false);
    }
  }
}