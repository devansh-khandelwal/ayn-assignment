// screen1_bloc.dart
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:dio/dio.dart';
import 'package:hive/hive.dart';

enum Screen1Event { fetchMedia, saveMediaAndNavigate }

class Screen1State {
  final bool loading;
  final dynamic mediaData;

  Screen1State({required this.loading, this.mediaData});
}

class Screen1Bloc extends Bloc<Screen1Event, Screen1State> {
  Screen1Bloc() : super(Screen1State(loading: false));

  @override
  Stream<Screen1State> mapEventToState(Screen1Event event) async* {
    print(Screen1Event);
    if (event == Screen1Event.fetchMedia) {
      yield* _mapFetchMediaToState();
    } else if (event == Screen1Event.saveMediaAndNavigate) {
      yield* _mapSaveMediaAndNavigateToState();
    }
  }

  Stream<Screen1State> _mapFetchMediaToState() async* {
    yield Screen1State(loading: true);
    try {
      final response = await Dio().get('https://random.dog/woof.json');
      final data = response.data;
      print(response.data);
      print("hello");
      yield Screen1State(loading: false, mediaData: data);
    } catch (e) {
      yield Screen1State(loading: false);
      print('Error: $e');
    }
  }

  Stream<Screen1State> _mapSaveMediaAndNavigateToState() async* {
    final box = await Hive.openBox('media');
    await box.add(state.mediaData);
    yield state;
  }
}