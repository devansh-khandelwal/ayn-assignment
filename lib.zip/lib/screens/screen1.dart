// screen1.dart
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../blocs/screen1_bloc.dart';
import '../video_widget.dart';

class Screen1 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => Screen1Bloc(),
      child: Screen1View(),
    );
  }
}

class Screen1View extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final screen1Bloc = BlocProvider.of<Screen1Bloc>(context);

    return Scaffold(
      appBar: AppBar(
        title: Text('Screen 1'),
        centerTitle: true,
      ),
      body: BlocBuilder<Screen1Bloc, Screen1State>(

        builder: (context, state) {
          print('yoyo');
          return Center(
            child: state.loading
                ? CircularProgressIndicator()
                : Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                state.mediaData != null
                    ? state.mediaData['url'].endsWith('.mp4')
                    ? SizedBox(
                  height: MediaQuery.of(context).size.height /
                      2,
                  child: VideoWidget(
                      videoUrl: state.mediaData['url']),
                )
                    : Image.network(
                  state.mediaData['url'],
                  height:
                  MediaQuery.of(context).size.height / 2,
                  loadingBuilder: (context, child, progress) {
                    return progress == null
                        ? child
                        : CircularProgressIndicator();
                  },
                )
                    : Text('Failed to load media'),
                SizedBox(height: 16),
                Align(
                  alignment: Alignment.centerRight,
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: FloatingActionButton(
                      onPressed: () {
                        screen1Bloc.add(Screen1Event.saveMediaAndNavigate);
                      },
                      child: Icon(Icons.arrow_right),
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
