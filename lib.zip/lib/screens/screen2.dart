// screen2.dart
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../blocs/screen2_bloc.dart';

class Screen2 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => Screen2Bloc(),
      child: Screen2View(),
    );
  }
}

class Screen2View extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final screen2Bloc = BlocProvider.of<Screen2Bloc>(context);
    return Scaffold(
      appBar: AppBar(
        title: Text('Screen 2'),
        centerTitle: true,
      ),
      body: BlocBuilder<Screen2Bloc, Screen2State>(
        builder: (context, state) {
          return state.loading
              ? Center(
            child: CircularProgressIndicator(),
          )
              : ListView.separated(
            itemCount: state.posts.length,
            itemBuilder: (context, index) {
              final post = state.posts[index];
              return Container(
                margin: EdgeInsets.symmetric(
                    vertical: 6.0, horizontal: 20.0),
                decoration: BoxDecoration(
                  color: Color(0xFFE3F2FD),
                  borderRadius: BorderRadius.circular(8.0),
                ),
                child: ListTile(
                  title: Text(
                    post['title'],
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 18.0,
                    ),
                  ),
                  subtitle: Text(
                    post['body'],
                    style: TextStyle(
                      color: Colors.black,
                    ),
                  ),
                ),
              );
            },
            separatorBuilder: (context, index) {
              return Divider();
            },
          );
        },
      ),
    );
  }
}
